public class BinaryNode {
    // BinaryNode root;
    // OrderedKeyValue keyValue;
    BinaryNode leftChild;
    BinaryNode rightChild;
}
