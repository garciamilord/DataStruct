Source currency is USD
Kuwaiti Dinar: max exchange rate is 0.3080641108582112 and direct rate is 0.306859
Bahraini Dinar: max exchange rate is 0.37700778212385355 and direct rate is 0.376
Omani Rial: max exchange rate is 0.3856710590964678 and direct rate is 0.3845
British Pound: max exchange rate is 0.7881492967743342 and direct rate is 0.785824
Euro: max exchange rate is 0.8659397128593971 and direct rate is 0.863744
Swiss Franc: max exchange rate is 0.9321999863055623 and direct rate is 0.92926
Canadian Dollar: max exchange rate is 1.345284128094142 and direct rate is 1.340709
Bruneian Dollar: max exchange rate is 1.3888621976775801 and direct rate is 1.384036
Singapore Dollar: max exchange rate is 1.3868976237295716 and direct rate is 1.384036
Libyan Dinar: max exchange rate is 1.396795327057715 and direct rate is 1.391679
Australian Dollar: max exchange rate is 1.4042813298343404 and direct rate is 1.399751
New Zealand Dollar: max exchange rate is 1.5047259415090484 and direct rate is 1.50011
Bulgarian Lev: max exchange rate is 1.6941682676144638 and direct rate is 1.689337
Israeli Shekel: max exchange rate is 3.4300204332426683 and direct rate is 3.41983
Qatari Riyal: max exchange rate is 3.6522896337351884 and direct rate is 3.64
Emirati Dirham: max exchange rate is 3.6855932160479807 and direct rate is 3.6725
Saudi Arabian Riyal: max exchange rate is 3.7599711628562043 and direct rate is 3.75
Polish Zloty: max exchange rate is 3.836423373844969 and direct rate is 3.819105
Romanian New Leu: max exchange rate is 4.187056767724665 and direct rate is 4.176897
Malaysian Ringgit: max exchange rate is 4.267683653289027 and direct rate is 4.250934
Brazilian Real: max exchange rate is 5.116404480834851 and direct rate is 5.098128
Danish Krone: max exchange rate is 6.44981078699514 and direct rate is 6.428258
Croatian Kuna: max exchange rate is 6.520284579859755 and direct rate is 6.498288
Trinidadian Dollar: max exchange rate is 6.7810967185333135 and direct rate is 6.761225
Turkish Lira: max exchange rate is 6.873431487258438 and direct rate is 6.849881
Chinese Yuan Renminbi: max exchange rate is 7.024903471773302 and direct rate is 7.000243
Hong Kong Dollar: max exchange rate is 7.773080127800149 and direct rate is 7.752142
Swedish Krona: max exchange rate is 8.898788065023053 and direct rate is 8.860053
Norwegian Krone: max exchange rate is 9.157644555428435 and direct rate is 9.131606
Venezuelan Bolivar: max exchange rate is 10.025774801885325 and direct rate is 9.9875
Botswana Pula: max exchange rate is 11.573213767749559 and direct rate is 11.541719
South African Rand: max exchange rate is 16.50791580680169 and direct rate is 16.458671
Mexican Peso: max exchange rate is 22.33077444604718 and direct rate is 22.265196
Czech Koruna: max exchange rate is 22.856778080585595 and direct rate is 22.797157
Taiwan New Dollar: max exchange rate is 29.496920460622484 and direct rate is 29.406916
Thai Baht: max exchange rate is 31.723641557190817 and direct rate is 31.600253
Mauritian Rupee: max exchange rate is 40.142455345904075 and direct rate is 40.023897
Philippine Peso: max exchange rate is 49.49326855339566 and direct rate is 49.338157
Russian Ruble: max exchange rate is 71.29310479879547 and direct rate is 71.118397
Argentine Peso: max exchange rate is 71.96338860736161 and direct rate is 71.773598
Indian Rupee: max exchange rate is 74.81244002723862 and direct rate is 74.579725
Japanese Yen: max exchange rate is 107.46918208765865 and direct rate is 107.193994
Nepalese Rupee: max exchange rate is 120.23091337680476 and direct rate is 119.886909
Icelandic Krona: max exchange rate is 136.86259576667968 and direct rate is 136.308291
Pakistani Rupee: max exchange rate is 168.3307145442059 and direct rate is 167.836295
Sri Lankan Rupee: max exchange rate is 186.2558969992235 and direct rate is 185.758394
Hungarian Forint: max exchange rate is 301.5300920747312 and direct rate is 300.712829
Kazakhstani Tenge: max exchange rate is 414.6368870949053 and direct rate is 413.232748
Chilean Peso: max exchange rate is 772.0551592840475 and direct rate is 769.030721
South Korean Won: max exchange rate is 1201.3606644643164 and direct rate is 1196.25183
Colombian Peso: max exchange rate is 3635.646459854721 and direct rate is 3625.260128
Indonesian Rupiah: max exchange rate is 14682.411430980814 and direct rate is 14638.84475
Iranian Rial: max exchange rate is 203771.95672234666 and direct rate is 203430.0
USD: max exchange rate is 1.0 and direct rate is 1.0


Source currency is Euro
Kuwaiti Dinar: max exchange rate is 0.3560645644002918 and direct rate is 0.34986423924438115
Bahraini Dinar: max exchange rate is 0.43569796144772716 and direct rate is 0.4320967078594971
Omani Rial: max exchange rate is 0.4457440757800875 and direct rate is 0.44435206550915146
British Pound: max exchange rate is 0.9113686999087149 and direct rate is 0.9055724731249191
Euro: max exchange rate is 1.0 and direct rate is 1.0
Swiss Franc: max exchange rate is 1.0784961240621522 and direct rate is 1.0592705128012352
Canadian Dollar: max exchange rate is 1.5548971469933222 and direct rate is 1.5268582866539009
Bruneian Dollar: max exchange rate is 1.6052652548537476 and direct rate is 1.5992960636440974
Singapore Dollar: max exchange rate is 1.6047781477177736 and direct rate is 1.5913355716294904
Libyan Dinar: max exchange rate is 1.614434470473184 and direct rate is 1.6022535902709487
Australian Dollar: max exchange rate is 1.623015439552781 and direct rate is 1.5944880640413293
New Zealand Dollar: max exchange rate is 1.7399750664558054 and direct rate is 1.7204160734635092
Bulgarian Lev: max exchange rate is 1.9580558376169774 and direct rate is 1.9456429089332103
Israeli Shekel: max exchange rate is 3.9644628776922586 and direct rate is 3.94633111020479
Qatari Riyal: max exchange rate is 4.223931153524962 and direct rate is 4.209345502054148
Emirati Dirham: max exchange rate is 4.258353897782151 and direct rate is 4.224494558895594
Saudi Arabian Riyal: max exchange rate is 4.3458242848555715 and direct rate is 4.3136163806810055
Polish Zloty: max exchange rate is 4.433993556793986 and direct rate is 4.378156016261313
Romanian New Leu: max exchange rate is 4.843378195785986 and direct rate is 4.8086427474907865
Malaysian Ringgit: max exchange rate is 4.934529685869287 and direct rate is 4.852321480004994
Brazilian Real: max exchange rate is 5.916304079683382 and direct rate is 5.835816326778043
Danish Krone: max exchange rate is 7.456644507489607 and direct rate is 7.317202397236667
Croatian Kuna: max exchange rate is 7.538855850744484 and direct rate is 7.518402343893553
Trinidadian Dollar: max exchange rate is 7.840669449788623 and direct rate is 7.70621674537905
Turkish Lira: max exchange rate is 7.948025005023819 and direct rate is 7.915276339559348
Chinese Yuan Renminbi: max exchange rate is 8.11947613002642 and direct rate is 8.06814089170341
Hong Kong Dollar: max exchange rate is 8.988324876204068 and direct rate is 8.824964191875617
Swedish Krona: max exchange rate is 10.282176122196097 and direct rate is 10.214620558456964
Norwegian Krone: max exchange rate is 10.591508801082062 and direct rate is 10.363348442425096
Venezuelan Bolivar: max exchange rate is 11.587048245402357 and direct rate is 11.432601689225242
Botswana Pula: max exchange rate is 13.382858982116938 and direct rate is 13.212309237920605
South African Rand: max exchange rate is 19.08006692026153 and direct rate is 18.85152107718134
Mexican Peso: max exchange rate is 25.79015940065567 and direct rate is 25.31022739040592
Czech Koruna: max exchange rate is 26.43041350626706 and direct rate is 25.98533236110024
Taiwan New Dollar: max exchange rate is 34.09292989599686 and direct rate is 33.850470321004096
Thai Baht: max exchange rate is 36.66728755288025 and direct rate is 36.10252426502359
Mauritian Rupee: max exchange rate is 46.40880625145197 and direct rate is 46.25326398955078
Philippine Peso: max exchange rate is 57.155559236295126 and direct rate is 56.26650968331637
Russian Ruble: max exchange rate is 82.40151127701816 and direct rate is 82.33033286275823
Argentine Peso: max exchange rate is 83.17623414771153 and direct rate is 81.82880850088172
Indian Rupee: max exchange rate is 86.46539881659503 and direct rate is 85.06810178197233
Japanese Yen: max exchange rate is 124.10700247571214 and direct rate is 123.34058933330526
Nepalese Rupee: max exchange rate is 138.96447619198594 and direct rate is 136.46195055817728
Icelandic Krona: max exchange rate is 158.09909937886758 and direct rate is 155.36748514709748
Pakistani Rupee: max exchange rate is 194.55886108381776 and direct rate is 193.69769638234138
Sri Lankan Rupee: max exchange rate is 215.45152129686167 and direct rate is 213.43963422546128
Hungarian Forint: max exchange rate is 348.67136102537955 and direct rate is 343.66384272031064
Kazakhstani Tenge: max exchange rate is 478.97468297851265 and direct rate is 475.83229281553884
Chilean Peso: max exchange rate is 892.3515407804117 and direct rate is 886.6839358370023
South Korean Won: max exchange rate is 1388.058466650155 and direct rate is 1368.9285679022516
Colombian Peso: max exchange rate is 4202.128152595643 and direct rate is 4194.589184002581
Indonesian Rupiah: max exchange rate is 16978.977868973823 and direct rate is 16782.135524062352
Iranian Rial: max exchange rate is 235917.0734874532 and direct rate is 233380.39471322397
USD: max exchange rate is 1.1577504445761708 and direct rate is 1.1289337760823115


Source currency is British Pound
Kuwaiti Dinar: max exchange rate is 0.39140469244080367 and direct rate is 0.3868888293651884
Bahraini Dinar: max exchange rate is 0.4786878031663541 and direct rate is 0.4726751721391758
Omani Rial: max exchange rate is 0.48952161510056474 and direct rate is 0.4817128231818938
British Pound: max exchange rate is 1.0 and direct rate is 1.0
Euro: max exchange rate is 1.100202376835796 and direct rate is 1.0884539925130332
Swiss Franc: max exchange rate is 1.185445532731649 and direct rate is 1.1752646778405815
Canadian Dollar: max exchange rate is 1.7087119615157507 and direct rate is 1.7041924239766433
Bruneian Dollar: max exchange rate is 1.7635102180162812 and direct rate is 1.7418294619424863
Singapore Dollar: max exchange rate is 1.7635273316224218 and direct rate is 1.7371907626281005
Libyan Dinar: max exchange rate is 1.7741388850800455 and direct rate is 1.7698456935886695
Australian Dollar: max exchange rate is 1.7824154766669422 and direct rate is 1.7498437417311214
New Zealand Dollar: max exchange rate is 1.9115393154887512 and direct rate is 1.8764421937575608
Bulgarian Lev: max exchange rate is 2.1503609541189803 and direct rate is 2.14118987684579
Israeli Shekel: max exchange rate is 4.356638735363895 and direct rate is 4.3073620192144695
Qatari Riyal: max exchange rate is 4.644486691865612 and direct rate is 4.610305700004172
Emirati Dirham: max exchange rate is 4.682884874158815 and direct rate is 4.593056875198144
Saudi Arabian Riyal: max exchange rate is 4.775725489327327 and direct rate is 4.697669675479464
Polish Zloty: max exchange rate is 4.86946614706809 and direct rate is 4.770988190923106
Romanian New Leu: max exchange rate is 5.319057382410938 and direct rate is 5.236835739345128
Malaysian Ringgit: max exchange rate is 5.4209692110529035 and direct rate is 5.388985817091683
Brazilian Real: max exchange rate is 6.491669156814333 and direct rate is 6.450941689419211
Danish Krone: max exchange rate is 8.194932490171064 and direct rate is 8.158089136182852
Croatian Kuna: max exchange rate is 8.284620750137258 and direct rate is 8.199227153086992
Trinidadian Dollar: max exchange rate is 8.61441450700891 and direct rate is 8.431941350765518
Turkish Lira: max exchange rate is 8.731712638007853 and direct rate is 8.658882685348955
Chinese Yuan Renminbi: max exchange rate is 8.925350554908611 and direct rate is 8.754205843096814
Hong Kong Dollar: max exchange rate is 9.874587695240425 and direct rate is 9.86244631520082
Swedish Krona: max exchange rate is 11.301811363871865 and direct rate is 11.05963916183281
Norwegian Krone: max exchange rate is 11.623513142995257 and direct rate is 11.611869954664712
Venezuelan Bolivar: max exchange rate is 12.730329633272024 and direct rate is 12.551924850737192
Botswana Pula: max exchange rate is 14.702114526863797 and direct rate is 14.543437199983478
South African Rand: max exchange rate is 20.9675209940506 and direct rate is 20.713293367261432
Mexican Peso: max exchange rate is 28.36805834298435 and direct rate is 27.859107590440534
Czech Koruna: max exchange rate is 29.044984610908116 and direct rate is 28.8714763049169
Taiwan New Dollar: max exchange rate is 37.46549874958254 and direct rate is 36.83416720396938
Thai Baht: max exchange rate is 40.28520874514827 and direct rate is 39.73406058631912
Mauritian Rupee: max exchange rate is 51.00377707400152 and direct rate is 50.76725043984345
Philippine Peso: max exchange rate is 62.82836406886742 and direct rate is 62.549933468511576
Russian Ruble: max exchange rate is 90.58002790128889 and direct rate is 89.38570586015355
Argentine Peso: max exchange rate is 91.40426199691258 and direct rate is 90.09075377081402
Indian Rupee: max exchange rate is 94.95736225981024 and direct rate is 93.19909100644563
Japanese Yen: max exchange rate is 136.5428191057445 and direct rate is 134.7965694352844
Nepalese Rupee: max exchange rate is 152.71123440812184 and direct rate is 152.33051358688812
Icelandic Krona: max exchange rate is 173.83595746567462 and direct rate is 172.40581198847715
Pakistani Rupee: max exchange rate is 213.86922147786274 and direct rate is 209.85816701890167
Sri Lankan Rupee: max exchange rate is 236.61150514796125 and direct rate is 235.68893547325473
Hungarian Forint: max exchange rate is 383.0160836963852 and direct rate is 379.18053686070124
Kazakhstani Tenge: max exchange rate is 526.6508344734893 and direct rate is 515.6828363003191
Chilean Peso: max exchange rate is 980.3183962716505 and direct rate is 968.1023595824726
South Korean Won: max exchange rate is 1525.0500565184386 and direct rate is 1519.017544340763
Colombian Peso: max exchange rate is 4619.197869166539 and direct rate is 4546.226694026359
Indonesian Rupiah: max exchange rate is 18651.9059200605 and direct rate is 18449.11218712946
Iranian Rial: max exchange rate is 259309.91764357773 and direct rate is 255117.65687975948
USD: max exchange rate is 1.2725495785315797 and direct rate is 1.2675809283876338
